CREATE DATABASE reposteria_pedidos;
USE reposteria_pedidos;

-- =====================================
-- TABLA USUARIOS
-- =====================================
CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telefono VARCHAR(20),
    direccion VARCHAR(150),
    contrasena VARCHAR(255) NOT NULL,
    rol ENUM('cliente', 'administrador') DEFAULT 'cliente'
);

-- =====================================
-- TABLA CATEGORIAS
-- =====================================
CREATE TABLE categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre_categoria VARCHAR(100) NOT NULL,
    descripcion TEXT
);

-- =====================================
-- TABLA PRODUCTOS
-- =====================================
CREATE TABLE productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    id_categoria INT,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (id_categoria)
    REFERENCES categorias(id_categoria)
);

-- =====================================
-- TABLA PEDIDOS
-- =====================================
CREATE TABLE pedidos (
    id_pedido INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT,
    fecha_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10,2),

    FOREIGN KEY (id_cliente)
    REFERENCES usuarios(id_usuario)
);

-- =====================================
-- TABLA DETALLE PEDIDOS
-- =====================================
CREATE TABLE detalle_pedidos (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT,
    id_producto INT,
    cantidad INT NOT NULL,
    subtotal DECIMAL(10,2),

    FOREIGN KEY (id_pedido)
    REFERENCES pedidos(id_pedido),

    FOREIGN KEY (id_producto)
    REFERENCES productos(id_producto)
);

-- =====================================
-- TABLA PAGOS
-- =====================================
CREATE TABLE pagos (
    id_pago INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT UNIQUE,
    metodo_pago VARCHAR(50),
    fecha_pago DATETIME DEFAULT CURRENT_TIMESTAMP,
    estado_pago ENUM('pendiente', 'pagado', 'cancelado')
    DEFAULT 'pendiente',

    FOREIGN KEY (id_pedido)
    REFERENCES pedidos(id_pedido)
);

-- =====================================
-- TABLA CALIFICACIONES
-- =====================================
CREATE TABLE calificaciones (
    id_calificacion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    id_producto INT,
    puntuacion INT CHECK (puntuacion BETWEEN 1 AND 5),
    comentario TEXT,
    fecha_calificacion DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario),

    FOREIGN KEY (id_producto)
    REFERENCES productos(id_producto)
);

-- =====================================
-- REGISTROS DE PRUEBA
-- =====================================

-- Usuario
INSERT INTO usuarios
(nombre, email, telefono, direccion, contrasena, rol)
VALUES
('Maria Lopez',
'maria@gmail.com',
'3001234567',
'Bucaramanga',
'12345',
'cliente');

-- Categoria
INSERT INTO categorias
(nombre_categoria, descripcion)
VALUES
('Tortas',
'Tortas personalizadas');

-- Producto
INSERT INTO productos
(id_categoria, nombre, descripcion, precio)
VALUES
(1,
'Torta de Chocolate',
'Torta personalizada',
85000);

-- Pedido
INSERT INTO pedidos
(id_cliente, total)
VALUES
(1, 85000);

-- Detalle del pedido
INSERT INTO detalle_pedidos
(id_pedido, id_producto, cantidad, subtotal)
VALUES
(1, 1, 1, 85000);

-- Pago
INSERT INTO pagos
(id_pedido, metodo_pago, estado_pago)
VALUES
(1, 'Transferencia', 'pagado');

-- Calificacion
INSERT INTO calificaciones
(id_usuario, id_producto, puntuacion, comentario)
VALUES
(1, 1, 5, 'Excelente producto');
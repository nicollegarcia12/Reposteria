CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telefono VARCHAR(20),
    direccion VARCHAR(150),
    contrasena VARCHAR(255) NOT NULL,
    rol ENUM('cliente', 'administrador') DEFAULT 'cliente'
);

CREATE TABLE IF NOT EXISTS categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre_categoria VARCHAR(100) NOT NULL,
    descripcion TEXT
);

CREATE TABLE IF NOT EXISTS productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    id_categoria INT,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (id_categoria)
    REFERENCES categorias(id_categoria)
);

-- 🔥 CORREGIDO: ahora es RELACIONAL
CREATE TABLE IF NOT EXISTS pedidos (
    id_pedido INT AUTO_INCREMENT PRIMARY KEY,

    cliente VARCHAR(100) NOT NULL,
    telefono VARCHAR(20),

    id_producto INT NOT NULL,
    cantidad INT NOT NULL,

    observaciones TEXT,
    metodo_pago VARCHAR(50),

    total DECIMAL(10,2),

    estado ENUM(
        'tomado',
        'en proceso',
        'entregado',
        'cancelado'
    ) DEFAULT 'tomado',

    fecha_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_producto)
    REFERENCES productos(id_producto)
);

CREATE TABLE IF NOT EXISTS detalle_pedidos (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT,
    id_producto INT,
    cantidad INT NOT NULL,
    subtotal DECIMAL(10,2),

    FOREIGN KEY (id_pedido)
    REFERENCES pedidos(id_pedido),

    FOREIGN KEY (id_producto)
    REFERENCES productos(id_producto)
);

CREATE TABLE IF NOT EXISTS pagos (
    id_pago INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT UNIQUE,
    metodo_pago VARCHAR(50),
    fecha_pago DATETIME DEFAULT CURRENT_TIMESTAMP,

    estado_pago ENUM('pendiente', 'pagado', 'cancelado') DEFAULT 'pendiente',

    FOREIGN KEY (id_pedido)
    REFERENCES pedidos(id_pedido)
);

CREATE TABLE IF NOT EXISTS calificaciones (
    id_calificacion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    id_producto INT,

    puntuacion INT CHECK (puntuacion BETWEEN 1 AND 5),
    comentario TEXT,

    fecha_calificacion DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario),

    FOREIGN KEY (id_producto)
    REFERENCES productos(id_producto)
);
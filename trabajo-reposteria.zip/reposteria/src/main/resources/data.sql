-- =====================================
-- USUARIO DE PRUEBA
-- =====================================

INSERT INTO usuarios
(nombre, email, telefono, direccion, contrasena, rol)
SELECT
'Maria Lopez',
'maria@gmail.com',
'3001234567',
'Bucaramanga',
'12345',
'administrador'
WHERE NOT EXISTS (
    SELECT 1
    FROM usuarios
    WHERE email = 'maria@gmail.com'
);

-- =====================================
-- CATEGORIAS
-- =====================================

INSERT INTO categorias
(nombre_categoria, descripcion)
SELECT
'Tortas',
'Tortas personalizadas'
WHERE NOT EXISTS (
    SELECT 1
    FROM categorias
    WHERE nombre_categoria = 'Tortas'
);

INSERT INTO categorias
(nombre_categoria, descripcion)
SELECT
'Postres',
'Postres individuales'
WHERE NOT EXISTS (
    SELECT 1
    FROM categorias
    WHERE nombre_categoria = 'Postres'
);

-- =====================================
-- PRODUCTOS
-- =====================================

INSERT INTO productos
(id_categoria, nombre, descripcion, precio)
SELECT
1,
'Torta de Chocolate',
'Torta personalizada de chocolate',
85000
WHERE NOT EXISTS (
    SELECT 1
    FROM productos
    WHERE nombre = 'Torta de Chocolate'
);

INSERT INTO productos
(id_categoria, nombre, descripcion, precio)
SELECT
1,
'Torta de Vainilla',
'Torta personalizada de vainilla',
78000
WHERE NOT EXISTS (
    SELECT 1
    FROM productos
    WHERE nombre = 'Torta de Vainilla'
);

INSERT INTO productos
(id_categoria, nombre, descripcion, precio)
SELECT
2,
'Cheesecake',
'Porción individual',
15000
WHERE NOT EXISTS (
    SELECT 1
    FROM productos
    WHERE nombre = 'Cheesecake'
);

INSERT INTO productos
(id_categoria, nombre, descripcion, precio)
SELECT
2,
'Tres Leches',
'Postre individual',
12000
WHERE NOT EXISTS (
    SELECT 1
    FROM productos
    WHERE nombre = 'Tres Leches'
);

-- =====================================
-- PEDIDOS
-- =====================================

INSERT INTO pedidos
(cliente, telefono, id_producto, cantidad,
observaciones, metodo_pago, total, estado)
SELECT
'Maria Lopez',
'3001234567',
1,
1,
'Sin azúcar',
'Efectivo',
85000,
'tomado'
WHERE NOT EXISTS (
    SELECT 1
    FROM pedidos
    WHERE cliente = 'Maria Lopez'
    AND total = 85000
);

INSERT INTO pedidos
(cliente, telefono, id_producto, cantidad,
observaciones, metodo_pago, total, estado)
SELECT
'Juan Perez',
'3012223344',
3,
1,
'Normal',
'Transferencia',
15000,
'en proceso'
WHERE NOT EXISTS (
    SELECT 1
    FROM pedidos
    WHERE cliente = 'Juan Perez'
    AND total = 15000
);

INSERT INTO pedidos
(cliente, telefono, id_producto, cantidad,
observaciones, metodo_pago, total, estado)
SELECT
'Laura Gomez',
'3124445566',
4,
1,
'Decoración especial',
'Nequi',
12000,
'entregado'
WHERE NOT EXISTS (
    SELECT 1
    FROM pedidos
    WHERE cliente = 'Laura Gomez'
    AND total = 12000
);

INSERT INTO pedidos
(cliente, telefono, id_producto, cantidad,
observaciones, metodo_pago, total, estado)
SELECT
'Carlos Ruiz',
'3201112233',
2,
1,
'Sin crema',
'Efectivo',
78000,
'cancelado'
WHERE NOT EXISTS (
    SELECT 1
    FROM pedidos
    WHERE cliente = 'Carlos Ruiz'
    AND total = 78000
);

-- =====================================
-- DETALLE PEDIDOS
-- =====================================

INSERT INTO detalle_pedidos
(id_pedido, id_producto, cantidad, subtotal)
SELECT
1,1,1,85000
WHERE NOT EXISTS (
    SELECT 1
    FROM detalle_pedidos
    WHERE id_pedido = 1
    AND id_producto = 1
);

INSERT INTO detalle_pedidos
(id_pedido, id_producto, cantidad, subtotal)
SELECT
2,3,1,15000
WHERE NOT EXISTS (
    SELECT 1
    FROM detalle_pedidos
    WHERE id_pedido = 2
    AND id_producto = 3
);

INSERT INTO detalle_pedidos
(id_pedido, id_producto, cantidad, subtotal)
SELECT
3,4,1,12000
WHERE NOT EXISTS (
    SELECT 1
    FROM detalle_pedidos
    WHERE id_pedido = 3
    AND id_producto = 4
);

INSERT INTO detalle_pedidos
(id_pedido, id_producto, cantidad, subtotal)
SELECT
4,2,1,78000
WHERE NOT EXISTS (
    SELECT 1
    FROM detalle_pedidos
    WHERE id_pedido = 4
    AND id_producto = 2
);

-- =====================================
-- PAGOS
-- =====================================

INSERT INTO pagos
(id_pedido, metodo_pago, estado_pago)
SELECT
1,
'Efectivo',
'pagado'
WHERE NOT EXISTS (
    SELECT 1
    FROM pagos
    WHERE id_pedido = 1
);

INSERT INTO pagos
(id_pedido, metodo_pago, estado_pago)
SELECT
2,
'Transferencia',
'pendiente'
WHERE NOT EXISTS (
    SELECT 1
    FROM pagos
    WHERE id_pedido = 2
);

INSERT INTO pagos
(id_pedido, metodo_pago, estado_pago)
SELECT
3,
'Nequi',
'pagado'
WHERE NOT EXISTS (
    SELECT 1
    FROM pagos
    WHERE id_pedido = 3
);

INSERT INTO pagos
(id_pedido, metodo_pago, estado_pago)
SELECT
4,
'Efectivo',
'cancelado'
WHERE NOT EXISTS (
    SELECT 1
    FROM pagos
    WHERE id_pedido = 4
);
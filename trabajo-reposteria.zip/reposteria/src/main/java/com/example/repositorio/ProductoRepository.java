package com.example.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.modelo.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {
    // NO necesitas métodos extra para lo básico
}
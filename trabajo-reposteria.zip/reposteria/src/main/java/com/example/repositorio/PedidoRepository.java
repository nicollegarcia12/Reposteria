package com.example.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.modelo.Pedido;

public interface PedidoRepository
        extends JpaRepository<Pedido, Integer> {

}
package com.example.servicio;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import com.example.modelo.Usuario;
import com.example.repositorio.UsuarioRepository;

@Service
public class UsuarioService implements UserDetailsService {

    @Autowired
    private UsuarioRepository repo;

    @Override
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {

        Usuario usuario = repo.findByEmail(email);

        if (usuario == null) {
            throw new UsernameNotFoundException("Usuario no encontrado");
        }

        List<SimpleGrantedAuthority> roles = new ArrayList<>();

        // Toma el rol desde la base de datos
        roles.add(
            new SimpleGrantedAuthority(
                "ROLE_" + usuario.getRol().toUpperCase()
            )
        );

        return new org.springframework.security.core.userdetails.User(
                usuario.getEmail(),
                "{noop}" + usuario.getContrasena(),
                roles
        );
    }
}
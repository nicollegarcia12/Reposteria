package com.example.servicio;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.modelo.Pedido;
import com.example.modelo.Producto;
import com.example.repositorio.PedidoRepository;
import com.example.repositorio.ProductoRepository;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    public void guardarPedido(
            String cliente,
            String telefono,
            Integer productoId,
            Integer cantidad,
            String observaciones,
            String metodoPago
    ) {

        Producto producto = productoRepository.findById(productoId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        Double total = producto.getPrecio() * cantidad;

        Pedido pedido = new Pedido();

        pedido.setCliente(cliente);
        pedido.setTelefono(telefono);

        // ✔ AQUÍ ESTABA EL ERROR
        pedido.setProducto(producto);

        pedido.setCantidad(cantidad);
        pedido.setObservaciones(observaciones);
        pedido.setMetodoPago(metodoPago);

        pedido.setTotal(total);
        pedido.setEstado("tomado");
        pedido.setFechaPedido(LocalDateTime.now());

        pedidoRepository.save(pedido);
    }
}
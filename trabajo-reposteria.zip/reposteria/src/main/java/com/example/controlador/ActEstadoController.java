package com.example.controlador;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.modelo.Pedido;
import com.example.repositorio.PedidoRepository;

@Controller
public class ActEstadoController {

    @Autowired
    private PedidoRepository pedidoRepository;

    @PostMapping("/actualizarEstado")
    public String actualizarEstado(

            @RequestParam("id")
            Integer id,

            @RequestParam("estado")
            String estado

    ) {

        Optional<Pedido> pedidoOptional =
                pedidoRepository.findById(id);

        if (pedidoOptional.isPresent()) {

            Pedido pedido =
                    pedidoOptional.get();

            pedido.setEstado(
                    estado
            );

            pedidoRepository.save(
                    pedido
            );
        }

        return "redirect:/pedidos";
    }
}
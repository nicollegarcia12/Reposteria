package com.example.controlador;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.modelo.Pedido;
import com.example.repositorio.PedidoRepository;

@Controller
public class ControlController {

    @Autowired
    private PedidoRepository pedidoRepository;

    @GetMapping("/pedidos")
    public String verPedidos(Model model) {
        List<Pedido> pedidos = pedidoRepository.findAll();
        model.addAttribute("pedidos", pedidos);
        return "pedidos";
    }

    @GetMapping("/historial")
    public String verHistorial(Model model) {
        model.addAttribute("pedidos", pedidoRepository.findAll());
        return "historial";
    }

    @GetMapping("/reportes")
    public String verReportes(Model model) {
        List<Pedido> pedidos = pedidoRepository.findAll();

        double ventasTotales = 0;
        int entregados = 0;
        int cancelados = 0;
        Map<String, Integer> contadorProductos = new HashMap<>();

        for (Pedido pedido : pedidos) {
            // Ventas totales solo de pedidos entregados (o de todos, según tu lógica)
            // Lo dejamos como estaba: suma todos los totales
            if (pedido.getTotal() != null) {
                ventasTotales += pedido.getTotal();
            }

            // Contar entregados y cancelados
            if (pedido.getEstado() != null) {
                if (pedido.getEstado().equalsIgnoreCase("entregado")) {
                    entregados++;
                } else if (pedido.getEstado().equalsIgnoreCase("cancelado")) {
                    cancelados++;
                }
            }

            // Contar cantidad por producto (para el más vendido)
            if (pedido.getProducto() != null && pedido.getProducto().getNombre() != null) {
                String nombreProducto = pedido.getProducto().getNombre();
                int cantidad = (pedido.getCantidad() != null) ? pedido.getCantidad() : 0;
                contadorProductos.put(nombreProducto, 
                    contadorProductos.getOrDefault(nombreProducto, 0) + cantidad);
            }
        }

        // Encontrar el producto más vendido (mayor cantidad)
        String masVendido = "---";
        int maxCantidad = 0;
        for (Map.Entry<String, Integer> entry : contadorProductos.entrySet()) {
            if (entry.getValue() > maxCantidad) {
                maxCantidad = entry.getValue();
                masVendido = entry.getKey();
            }
        }

        model.addAttribute("pedidos", pedidos);
        model.addAttribute("ventasTotales", ventasTotales);
        model.addAttribute("totalPedidos", pedidos.size());  // Nombre corregido
        model.addAttribute("entregados", entregados);
        model.addAttribute("cancelados", cancelados);
        model.addAttribute("masVendido", masVendido);        // Nuevo atributo

        return "reportes";
    }
}
package com.example.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.servicio.PedidoService;

@Controller
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @PostMapping("/guardarPedido")
    public String guardarPedido(

            @RequestParam String cliente,

            @RequestParam(required = false)
            String telefono,

            @RequestParam Integer productoId,

            @RequestParam Integer cantidad,

            @RequestParam(required = false)
            String observaciones,

            @RequestParam String metodoPago

    ) {

        pedidoService.guardarPedido(
                cliente,
                telefono,
                productoId,
                cantidad,
                observaciones,
                metodoPago
        );

        return "redirect:/";
    }
}